fitted.siland<-function(object,...){
  return(object$fitted)
}