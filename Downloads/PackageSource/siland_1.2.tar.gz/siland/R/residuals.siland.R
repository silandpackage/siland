residuals.siland<-function(object,...)
{
  
  return(object$err)
}