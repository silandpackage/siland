fitted.Bsiland<-function(object,...){
  return(object$fitted)
}
