residuals.Fsiland<-function(object,...)
{
  
  return(object$err)
}
