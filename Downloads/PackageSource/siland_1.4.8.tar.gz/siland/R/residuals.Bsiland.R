residuals.Bsiland<-function(object,...)
{
  
  return(object$err)
}
