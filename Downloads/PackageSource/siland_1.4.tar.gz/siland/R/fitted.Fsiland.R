fitted.Fsiland<-function(object,...){
  return(object$fitted)
}
