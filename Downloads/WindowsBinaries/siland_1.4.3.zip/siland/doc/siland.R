## ----echo = FALSE, message = FALSE---------------------------------------
knitr::opts_chunk$set(collapse=T,
                      cache=T,
                      eval = FALSE)

#knitr::opts_chunk$set(eval = FALSE)
# options(width = 120, max.print = 100)

## ------------------------------------------------------------------------
#  library(siland)
#  data(dataSiland)
#  class(dataSiland)
#  data(landSiland)
#  class(landSiland)

## ----fig.align='center',fig.width=7--------------------------------------
#  par(mai=c(0,0,0,0),mar=c(0,0,0,0))
#  plot(landSiland$geometry,border=gray(0.6))
#  sel=landSiland$L1==1
#  plot(st_geometry(landSiland[sel,]),add=T,col=2)
#  sel=landSiland$L2==1
#  plot(st_geometry(landSiland[sel,]),add=T,col=3)
#  points(dataSiland[,c("X","Y")],pch=16,col=4)

## ------------------------------------------------------------------------
#  resB1=Bsiland(obs~x1+L1+L2,land=landSiland,data=dataSiland,family=gaussian)
#  resB1
#  summary(resB1)

## ------------------------------------------------------------------------
#  resB1$parambuffer

## ------------------------------------------------------------------------
#  resB2=Bsiland(obs~x1+L1+L2,land=landSiland,data=dataSiland,family=gaussian,border=T)
#  resB2$parambuffer

## ----fig.align='center',fig.width=7--------------------------------------
#  plotBsiland.land(x=resB1,land=landSiland,data=dataSiland,var=2)

## ----fig.align='center',fig.width=7--------------------------------------
#  plotBsiland.land(x=resB2,land=landSiland,data=dataSiland,var=2)

## ----fig.align='center',fig.width=7--------------------------------------
#  Bsiland.lik(resB1,land= landSiland, data=dataSiland,varnames=c("L1","L2"))

## ------------------------------------------------------------------------
#  resF1=Fsiland(obs~x1+L1+L2,land=landSiland,data=dataSiland,family=gaussian, sif="exponential",wd=50)
#  resF1
#  summary(resF1)

## ----fig.align='center',fig.width=7--------------------------------------
#  plotFsiland.sif(resF1)

## ----fig.align='center',fig.width=7--------------------------------------
#  plotFsiland.land(x=resF1,land=landSiland,data=dataSiland,var=2)

## ----fig.align='center',fig.width=7--------------------------------------
#  plotFsiland.land(x=resF1,land=landSiland,data=dataSiland)

## ----fig.align='center',fig.width=7--------------------------------------
#  par(mfrow=c(1,2))
#  plot(resB1$buffer[,1],resF1$landcontri[,1],xlab="buffer",ylab="land contri.")
#  abline(0,1)
#  plot(resB1$buffer[,2],resF1$landcontri[,2],xlab="buffer",ylab="land contri.")
#  abline(0,1)

## ------------------------------------------------------------------------
#  resB3=Bsiland(obs~x1+L1+L2+(1|Id),land=landSiland,data=dataSiland,family=gaussian)
#  summary(resB3)
#  resF3=Fsiland(obs~x1+L1+L2+(1|Id),land=landSiland,data=dataSiland,family=gaussian)
#  summary(resF3)

## ------------------------------------------------------------------------
#  #Model with main and interaction effect
#  resF4=Fsiland(obs~x1*L1+L2,land=landSiland,data=dataSiland,family=gaussian)
#  #Model with only interaction effect
#  resF5=Fsiland(obs~x1:L1+L2,land=landSiland,data=dataSiland,family=gaussian)
#  

## ------------------------------------------------------------------------
#  landSilandY1=landSiland
#  landSilandY2=landSiland
#  #landSilandY is a list with the landscape for each year
#  landSilandY=list(landSilandY1,landSilandY2)
#  dataSilandY1=dataSiland
#  dataSilandY2=dataSiland
#  dataSilandY1$year=factor("2018")
#  dataSilandY2$year=factor("2019")
#  colnames(dataSilandY1)
#  colnames(dataSilandY2)
#  head(dataSilandY1)
#  head(dataSilandY2)
#  dataSilandY=list(dataSilandY1,dataSilandY2)

## ------------------------------------------------------------------------
#  resY=Bsiland(obs~year+x1+L1+L2, land = landSilandY,data=dataSilandY)
#  resY
#  summary(resY)

## ------------------------------------------------------------------------
#  summary(resB1$result)
#  BIC(resB1$result)
#  fitted(resF1$result)[1:10]
#  residuals(resF1$result)[1:10]
#  class(resB1$result)
#  class(resF1$result)
#  

